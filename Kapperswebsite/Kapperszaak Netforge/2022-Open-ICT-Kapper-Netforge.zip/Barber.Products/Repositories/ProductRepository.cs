﻿using Barber.Products.DbContexts;
using Mango.Services.ProductApi.Models;
using Microsoft.EntityFrameworkCore;

namespace Barber.Products.Repositories
{
  
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext _db;

        public ProductRepository(ApplicationDbContext db)
        {
            _db = db;
        }

        public async Task<Product> GetProductById(int productId)
        {
            var product = await _db.Products.Where(x => x.Id == productId).FirstOrDefaultAsync();

            return product;
        }

        public async Task<IEnumerable<Product>> GetProducts()
        {
            var products = await _db.Products.ToListAsync();

            return products;
        }

        public async Task<Product> CreateProduct(Product product)
        {
            _db.Products.Add(product);
            await SaveChangesAsync();

            return product;
        }

        public async Task<Product> UpdateProduct(Product product)
        {
            _db.Products.Update(product);
            await SaveChangesAsync();

            return product;
        }

        public async Task DeleteProduct(int productId)
        {
            var product = await _db.Products.Where(x => x.Id == productId).FirstOrDefaultAsync();

            _db.Products.Remove(product);
            await SaveChangesAsync();
        }

        private async Task SaveChangesAsync()
        {
            await _db.SaveChangesAsync();
        }
    }
}
