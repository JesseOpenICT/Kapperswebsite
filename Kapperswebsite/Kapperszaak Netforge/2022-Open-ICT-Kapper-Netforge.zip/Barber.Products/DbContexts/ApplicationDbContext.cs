﻿using Mango.Services.ProductApi.Models;
using Microsoft.EntityFrameworkCore;

namespace Barber.Products.DbContexts
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        {
            base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Product>().HasData(new Product
            {
                Id = 1,
                Title = "New Wave Hairspray1",
                Description = "Extra strong",
                CategoryName = "Hairspray",
                Quantity = 20,
                Price = 5,
                ImageUrl = "https://barberstorage.blob.core.windows.net/storagecontainer/newwave1.jpg",
                Updated = DateTime.Now,
                Created = DateTime.Now
                
            });
            modelBuilder.Entity<Product>().HasData(new Product
            {
                Id = 2,
                Title = "New Wave Hairspray2",
                Description = "Extra strong",
                CategoryName = "Hairspray",
                Quantity = 20,
                Price = 5,
                ImageUrl = "https://barberstorage.blob.core.windows.net/storagecontainer/newwave2.jpg",
                Updated = DateTime.Now,
                Created = DateTime.Now
            });
            modelBuilder.Entity<Product>().HasData(new Product
            {
                Id = 3,
                Title = "New Wave Hairspray3",
                Description = "Extra strong",
                CategoryName = "Hairspray",
                Quantity = 20,
                Price = 5,
                ImageUrl = "https://barberstorage.blob.core.windows.net/storagecontainer/newwave3.jpg",
                Updated = DateTime.Now,
                Created = DateTime.Now
            });
            modelBuilder.Entity<Product>().HasData(new Product
            {
                Id = 4,
                Title = "New Wave Hairspray4",
                Description = "Extra strong",
                CategoryName = "Hairspray",
                Quantity = 20,
                Price = 5,
                ImageUrl = "https://barberstorage.blob.core.windows.net/storagecontainer/newwave4.jpg",
                Updated = DateTime.Now,
                Created = DateTime.Now
            });
        }
    }
}
    