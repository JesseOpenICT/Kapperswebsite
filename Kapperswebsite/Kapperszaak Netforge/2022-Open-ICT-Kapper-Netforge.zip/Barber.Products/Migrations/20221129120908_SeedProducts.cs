﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Barber.Products.Migrations
{
    /// <inheritdoc />
    public partial class SeedProducts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryName", "Created", "Description", "ImageUrl", "Price", "Quantity", "Title", "Updated" },
                values: new object[,]
                {
                    { 1, "Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2342), "Extra strong", "https://barberstorage.blob.core.windows.net/storagecontainer/newwave1.jpg", 5.0, 20, "New Wave Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2304) },
                    { 2, "Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2374), "Extra strong", "https://barberstorage.blob.core.windows.net/storagecontainer/newwave2.jpg", 5.0, 20, "New Wave Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2373) },
                    { 3, "Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2385), "Extra strong", "https://barberstorage.blob.core.windows.net/storagecontainer/newwave3.jpg", 5.0, 20, "New Wave Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2384) },
                    { 4, "Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2433), "Extra strong", "https://barberstorage.blob.core.windows.net/storagecontainer/newwave4.jpg", 5.0, 20, "New Wave Hairspray", new DateTime(2022, 11, 29, 13, 9, 8, 717, DateTimeKind.Local).AddTicks(2431) }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 4);
        }
    }
}
