﻿using AutoMapper;
using Barber.Products.Models.Dto;
using Barber.Products.Repositories;
using Mango.Services.ProductApi.Models;

namespace Barber.Products.Services
{
    public class ProductService : IProductService
    {
        private IProductRepository _productRepository;
        private IMapper _mapper;

        public ProductService(IProductRepository productRepository, IMapper mapper)
        {
            _productRepository = productRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<ProductDto>> GetProducts()
        {
            var products = await _productRepository.GetProducts();

            return _mapper.Map<List<ProductDto>>(products);
        }

        public async Task<ProductDto> GetProductById(int productId)
        {
            var products = await _productRepository.GetProductById(productId);

            return _mapper.Map<ProductDto>(products);
        }

        public async Task<ProductDto> CreateUpdateProduct(ProductDto productDto)
        {
            var product = _mapper.Map<ProductDto, Product>(productDto);

            if (product?.Id > 0)
            {
                await _productRepository.UpdateProduct(product);
            }
            else
            {
                await _productRepository.CreateProduct(product);
            }

            return _mapper.Map<Product, ProductDto>(product);
        }

        public async Task<bool> DeleteProduct(int productId)
        {
            try
            {
                var product = await _productRepository.GetProductById(productId);

                if (product == null)
                {
                    return false;
                }

                await _productRepository.DeleteProduct(product.Id);

                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
