﻿using AutoMapper;
using Barber.Products.Models.Dto;
using Mango.Services.ProductApi.Models;

namespace Barber.Products
{
    public class MappingConfig
    {
        //static zodat automapper dezelfde instantie krijgt over het gehele domein. dit is ook qua performance sneller
        public static MapperConfiguration RegisterMaps()
        {
            var mappingConfig = new MapperConfiguration(config =>
            {
                config.CreateMap<ProductDto, Product>();
                config.CreateMap<Product, ProductDto>();
            });

            return mappingConfig;
        }
    }
}
