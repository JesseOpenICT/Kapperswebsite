﻿using System.ComponentModel.DataAnnotations;

namespace Mango.Services.ProductApi.Models
{
    public class Product
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }
        public string CategoryName { get; set; }
        [Range(1, 1000)]
        public int Quantity { get; set; }
        public double Price { get; set; }
        public string ImageUrl { get; set; }
        public DateTime Updated { get; set; }
        public DateTime Created { get; set; }
    }
}
